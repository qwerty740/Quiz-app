const fs = require('fs');

// events data
let obj = [];
fs.readFile('./events.json', function (err, data) {
   if (err) {
      console.log(`Error reading file from disk: ${err}`);

   } else {

      const event = JSON.parse(data);

      for (let i = 0; i < event.length; i++) {
         const answerKey = event[i].quiz.pages;
         const map1 = new Map();

         for (let qus = 0; qus < answerKey.length; qus++) {

            id = answerKey[qus].elements[0].name;
            map1.set(id, {
               correctAns: answerKey[qus].elements[0].correctAnswer,
               marks: answerKey[qus].elements[0].Marks
            });


         }

         obj.push(Object.fromEntries(map1));


      }
   
   }
});


//  submission data
let subm = [];
fs.readFile('./submissions.json', function (err, data) {
   if (err) {
      console.log(`Error reading file from disk: ${err}`);

   }
   else {
      const response = JSON.parse(data);

      for (let i = 0; i < response.length; i++)
         subm.push(response[i].submission);

      //  Marks Calculations
      
      let t = 0;
      while (t < response.length) {
         let totalMarks = 0, obtainedMarks = 0;
         for (const i in obj[t]) {
            const quesMark = parseInt(obj[t][i].marks);

            totalMarks = totalMarks + quesMark;
          
            for (const j in subm[t]) {
               if (j === i && (obj[t][i].correctAns === subm[t][j])) {
                  obtainedMarks = obtainedMarks + quesMark;
               }

            }
         }
       
         percentage = 100 * obtainedMarks / totalMarks;

         if (percentage < 50) {
            console.log(`You got ${percentage} Work Hard!`);
         }

         else {
            console.log(`You got ${percentage} Keep Going!`);
         }

         t = t + 1;

      }
   }

});